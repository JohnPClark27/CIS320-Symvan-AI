# app.py
import os
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_cors import CORS
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()

# =========================
# Flask & DB setup
# =========================
app = Flask(__name__)
CORS(app)  # allow cross-origin requests (PHP frontend)

app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev")

db = SQLAlchemy(app)
migrate = Migrate(app, db)

# =========================
# Models
# =========================
class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    organization_id = db.Column(db.Integer, nullable=False)
    details = db.Column(db.Text, nullable=True)
    date = db.Column(db.Date, nullable=True)
    start_time = db.Column(db.Time, nullable=True)
    end_time = db.Column(db.Time, nullable=True)
    location = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(50), default="Draft")

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    level = db.Column(db.String(50), default="User")

class Organization(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)

# =========================
# Helper functions
# =========================
def parse_date(date_str):
    if not date_str:
        return None
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        return None

def parse_time(time_str):
    if not time_str:
        return None
    try:
        return datetime.strptime(time_str, "%H:%M").time()
    except ValueError:
        return None

# =========================
# Health check
# =========================
@app.route("/health", methods=["GET"])
def health_check():
    return jsonify({"status": "ok"}), 200

# =========================
# EVENT ROUTES
# =========================
@app.route("/create_event", methods=["POST"])
def create_event():
    data = request.get_json()
    try:
        event = Event(
            name=data['name'],
            organization_id=data['organization_id'],
            details=data.get('details'),
            date=parse_date(data.get('date')),
            start_time=parse_time(data.get('start_time')),
            end_time=parse_time(data.get('end_time')),
            location=data.get('location'),
            status=data.get('status', 'Draft')
        )
        db.session.add(event)
        db.session.commit()
        return jsonify({"message": "Event created successfully", "event_id": event.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 400

@app.route("/events", methods=["GET"])
def get_events():
    events = Event.query.all()
    return jsonify([
        {
            "id": e.id,
            "name": e.name,
            "organization_id": e.organization_id,
            "details": e.details,
            "date": e.date.strftime("%Y-%m-%d") if e.date else None,
            "start_time": e.start_time.strftime("%H:%M") if e.start_time else None,
            "end_time": e.end_time.strftime("%H:%M") if e.end_time else None,
            "location": e.location,
            "status": e.status
        }
        for e in events
    ]), 200

@app.route("/event/<int:event_id>", methods=["GET"])
def get_event(event_id):
    event = Event.query.get(event_id)
    if not event:
        return jsonify({"error": "Event not found"}), 404
    return jsonify({
        "id": event.id,
        "name": event.name,
        "organization_id": event.organization_id,
        "details": event.details,
        "date": event.date.strftime("%Y-%m-%d") if event.date else None,
        "start_time": event.start_time.strftime("%H:%M") if event.start_time else None,
        "end_time": event.end_time.strftime("%H:%M") if event.end_time else None,
        "location": event.location,
        "status": event.status
    }), 200

@app.route("/update_event/<int:event_id>", methods=["PUT"])
def update_event(event_id):
    data = request.get_json()
    event = Event.query.get(event_id)
    if not event:
        return jsonify({"error": "Event not found"}), 404
    try:
        event.name = data.get('name', event.name)
        event.organization_id = data.get('organization_id', event.organization_id)
        event.details = data.get('details', event.details)
        event.date = parse_date(data.get('date')) or event.date
        event.start_time = parse_time(data.get('start_time')) or event.start_time
        event.end_time = parse_time(data.get('end_time')) or event.end_time
        event.location = data.get('location', event.location)
        event.status = data.get('status', event.status)
        db.session.commit()
        return jsonify({"message": "Event updated successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 400

@app.route("/delete_event/<int:event_id>", methods=["DELETE"])
def delete_event(event_id):
    event = Event.query.get(event_id)
    if not event:
        return jsonify({"error": "Event not found"}), 404
    try:
        db.session.delete(event)
        db.session.commit()
        return jsonify({"message": "Event deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 400

# =========================
# ORGANIZATION ROUTES
# =========================
@app.route("/organizations", methods=["GET"])
def get_organizations():
    orgs = Organization.query.all()
    return jsonify([{"id": o.id, "name": o.name, "description": o.description} for o in orgs]), 200

# =========================
# USER ROUTES
# =========================
@app.route("/create_user", methods=["POST"])
def create_user():
    data = request.get_json()
    if not data or "username" not in data or "password_hash" not in data:
        return jsonify({"error": "Missing username or password"}), 400
    try:
        user = User(
            username=data["username"],
            email=data.get("email", ""),
            password_hash=data["password_hash"],
            level=data.get("level", "User")
        )
        db.session.add(user)
        db.session.commit()
        return jsonify({"message": "User created successfully", "user_id": user.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 400

from flask import Flask, request, jsonify

@app.route("/login", methods=["POST"])
def login_user():
    data = request.get_json()
    email = data.get("email")
    password = data.get("password")

    if not email or not password:
        return jsonify({"error": "Email and password required"}), 400

    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({"error": "User not found"}), 404

    if user.password_hash == password:
        return jsonify({"message": "Login successful", "user_id": user.id}), 200
    else:
        return jsonify({"error": "Invalid password"}), 401


@app.route("/users", methods=["GET"])
def get_users():
    users = User.query.all()
    return jsonify([{"id": u.id, "username": u.username, "email": u.email, "level": u.level} for u in users]), 200

# =========================
# Run server
# =========================
if __name__ == "__main__":
    app.run(port=5000, debug=True)
