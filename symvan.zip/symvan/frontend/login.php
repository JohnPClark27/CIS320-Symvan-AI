<?php
session_start(); // Start PHP session

$error = '';
$debugInfo = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Collect form data
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        $error = "Please fill in all required fields.";
    } else {
        $loginData = [
            'email' => $email,
            'password' => $password
        ];

        // Try localhost first
        $appUrls = [
            'http://127.0.0.1:5000/login',
            'http://localhost:5000/login'
        ];

        $success = false;

        foreach ($appUrls as $appUrl) {
            $ch = curl_init($appUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($loginData));

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr = curl_error($ch);
            curl_close($ch);

            // Debug info for development
            $debugInfo .= "URL: $appUrl\nHTTP Code: $httpCode\ncURL Error: $curlErr\nResponse: $response\n\n";

            if ($response !== false && $httpCode === 200) {
                $resData = json_decode($response, true);
                if (isset($resData['user_id'])) {
                    // Login successful
                    $_SESSION['user_id'] = $resData['user_id'];
                    $_SESSION['email'] = $email;
                    header("Location: index.php");
                    exit();
                } else {
                    $error = $resData['error'] ?? "Unknown login error.";
                    $success = true;
                    break;
                }
            }
        }

        if (!$success && empty($error)) {
            $error = "Could not reach Flask server. Check if Flask is running and listening on port 5000.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - Symvan</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-container">
        <div class="auth-logo">
            <h1>Symvan</h1>
            <p class="text-grey">Campus Event Management</p>
        </div>

        <div class="form-container">
            <h2 class="text-center mb-md">Welcome Back</h2>

            <?php if (!empty($error)) : ?>
                <p class="error-message" style="color: red;"><?= htmlspecialchars($error) ?></p>
            <?php endif; ?>

            <form action="login.php" method="POST">
                <div class="form-group">
                    <label for="email" class="form-label">Email Address</label>
                    <input type="email" id="email" name="email" class="form-input" placeholder="your.email@university.edu" required>
                </div>

                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" id="password" name="password" class="form-input" placeholder="Enter your password" required>
                </div>

                <div class="form-group">
                    <label>
                        <input type="checkbox" class="form-checkbox" name="remember">
                        Remember me
                    </label>
                </div>

                <button type="submit" class="btn btn-primary btn-block">Sign In</button>
            </form>

            <div class="auth-links">
                <p>Don't have an account? <a href="signup.php">Sign up here</a></p>
                <p><a href="contact.php">Forgot your password?</a></p>
            </div>

            <?php if (!empty($debugInfo)) : ?>
                <pre style="background: #f5f5f5; padding: 10px; margin-top: 20px; font-size: 12px; color: #333;">
<?= htmlspecialchars($debugInfo) ?>
                </pre>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
