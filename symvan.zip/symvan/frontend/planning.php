<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Planning Board - Symvan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- ===================================
         NAVIGATION BAR
         =================================== -->
    <nav class="navbar">
        <div class="navbar-container">
            <a href="index.html" class="navbar-brand">Symvan</a>
            <ul class="navbar-menu">
                <li><a href="index.html">Home</a></li>
                <li><a href="myevents.html">My Events</a></li>
                <li><a href="enroll.html">Enroll</a></li>
                <li><a href="create-event.html">Create Event</a></li>
                <li><a href="profile.html">Profile</a></li>
                <li><a href="contact.html">Contact</a></li>
            </ul>
        </div>
    </nav>
    
    <!-- ===================================
         EVENT PLANNING BOARD
         Kanban-style board with three columns
         =================================== -->
    <div class="container">
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">Event Planning Board</h1>
            <p class="page-subtitle">Track your event tasks and progress</p>
        </div>
        
        <!-- Kanban Board -->
        <div class="kanban-board">
            <!-- TO DO Column -->
            <div class="kanban-column">
                <div class="kanban-header">To Do</div>
                <div class="kanban-tasks">
                    <!-- Task 1 -->
                    <div class="kanban-task">
                        <div class="kanban-task-title">Book Venue for Workshop</div>
                        <div class="kanban-task-desc">Reserve Tech Lab 101 for October 20th event</div>
                    </div>
                    
                    <!-- Task 2 -->
                    <div class="kanban-task">
                        <div class="kanban-task-title">Design Event Poster</div>
                        <div class="kanban-task-desc">Create promotional materials for Career Fair</div>
                    </div>
                    
                    <!-- Task 3 -->
                    <div class="kanban-task">
                        <div class="kanban-task-title">Order Catering</div>
                        <div class="kanban-task-desc">Arrange food and beverages for Leadership Summit</div>
                    </div>
                    
                    <!-- Task 4 -->
                    <div class="kanban-task">
                        <div class="kanban-task-title">Create Registration Form</div>
                        <div class="kanban-task-desc">Set up online registration for Photography Workshop</div>
                    </div>
                    
                    <!-- Task 5 -->
                    <div class="kanban-task">
                        <div class="kanban-task-title">Contact Guest Speaker</div>
                        <div class="kanban-task-desc">Confirm availability for Data Science Seminar</div>
                    </div>
                </div>
            </div>
            
            <!-- IN PROGRESS Column -->
            <div class="kanban-column">
                <div class="kanban-header">In Progress</div>
                <div class="kanban-tasks">
                    <!-- Task 1 -->
                    <div class="kanban-task">
                        <div class="kanban-task-title">Send Invitations</div>
                        <div class="kanban-task-desc">Email invites to all registered participants</div>
                    </div>
                    
                    <!-- Task 2 -->
                    <div class="kanban-task">
                        <div class="kanban-task-title">Prepare Presentation Slides</div>
                        <div class="kanban-task-desc">Create content for Web Development Workshop</div>
                    </div>
                    
                    <!-- Task 3 -->
                    <div class="kanban-task">
                        <div class="kanban-task-title">Setup AV Equipment</div>
                        <div class="kanban-task-desc">Test projector and microphones in Main Auditorium</div>
                    </div>
                    
                    <!-- Task 4 -->
                    <div class="kanban-task">
                        <div class="kanban-task-title">Print Name Tags</div>
                        <div class="kanban-task-desc">Prepare badges for all Career Fair attendees</div>
                    </div>
                </div>
            </div>
            
            <!-- COMPLETED Column -->
            <div class="kanban-column">
                <div class="kanban-header">Completed</div>
                <div class="kanban-tasks">
                    <!-- Task 1 -->
                    <div class="kanban-task">
                        <div class="kanban-task-title">Event Approval Received</div>
                        <div class="kanban-task-desc">All events approved by campus administration</div>
                    </div>
                    
                    <!-- Task 2 -->
                    <div class="kanban-task">
                        <div class="kanban-task-title">Social Media Campaign</div>
                        <div class="kanban-task-desc">Posted announcements on all platforms</div>
                    </div>
                    
                    <!-- Task 3 -->
                    <div class="kanban-task">
                        <div class="kanban-task-title">Budget Finalized</div>
                        <div class="kanban-task-desc">Secured funding for all upcoming events</div>
                    </div>
                    
                    <!-- Task 4 -->
                    <div class="kanban-task">
                        <div class="kanban-task-title">Volunteer Team Assembled</div>
                        <div class="kanban-task-desc">Recruited 12 volunteers for event support</div>
                    </div>
                    
                    <!-- Task 5 -->
                    <div class="kanban-task">
                        <div class="kanban-task-title">Parking Arrangements</div>
                        <div class="kanban-task-desc">Reserved visitor parking spaces</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Add Task Section -->
        <div class="mt-lg">
            <div class="card" style="max-width: 600px; margin: 0 auto;">
                <h3 class="mb-md text-red">Quick Add Task</h3>
                <form action="planning.html">
                    <div class="form-group">
                        <label for="task-title" class="form-label">Task Title</label>
                        <input 
                            type="text" 
                            id="task-title" 
                            class="form-input" 
                            placeholder="Enter task name"
                        >
                    </div>
                    <div class="form-group">
                        <label for="task-desc" class="form-label">Description</label>
                        <input 
                            type="text" 
                            id="task-desc" 
                            class="form-input" 
                            placeholder="Brief description"
                        >
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Add to To Do</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>