<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Events - Symvan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- ===================================
         NAVIGATION BAR
         =================================== -->
    <nav class="navbar">
        <div class="navbar-container">
            <a href="index.html" class="navbar-brand">Symvan</a>
            <ul class="navbar-menu">
                <li><a href="index.html">Home</a></li>
                <li><a href="myevents.html" class="active">My Events</a></li>
                <li><a href="enroll.html">Enroll</a></li>
                <li><a href="create-event.html">Create Event</a></li>
                <li><a href="profile.html">Profile</a></li>
                <li><a href="contact.html">Contact</a></li>
            </ul>
        </div>
    </nav>
    
    <!-- ===================================
         MY EVENTS - CALENDAR PAGE
         Monthly calendar view of enrolled events
         =================================== -->
    <div class="container">
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">My Events Calendar</h1>
            <p class="page-subtitle">Your enrolled events for October 2025</p>
        </div>
        
        <!-- Calendar Header -->
        <div class="calendar-header">
            <div class="calendar-month">October 2025</div>
            <div>
                <a href="#" class="btn btn-outline">← Previous</a>
                <a href="#" class="btn btn-outline">Next →</a>
            </div>
        </div>
        
        <!-- Calendar Grid -->
        <div class="calendar-grid">
            <!-- Day Headers -->
            <div class="calendar-day-header">Sunday</div>
            <div class="calendar-day-header">Monday</div>
            <div class="calendar-day-header">Tuesday</div>
            <div class="calendar-day-header">Wednesday</div>
            <div class="calendar-day-header">Thursday</div>
            <div class="calendar-day-header">Friday</div>
            <div class="calendar-day-header">Saturday</div>
            
            <!-- Week 1 (Sept 28 - Oct 4) -->
            <div class="calendar-day" style="opacity: 0.5;">
                <div class="calendar-day-number">28</div>
            </div>
            <div class="calendar-day" style="opacity: 0.5;">
                <div class="calendar-day-number">29</div>
            </div>
            <div class="calendar-day" style="opacity: 0.5;">
                <div class="calendar-day-number">30</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">1</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">2</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">3</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">4</div>
            </div>
            
            <!-- Week 2 (Oct 5-11) -->
            <div class="calendar-day">
                <div class="calendar-day-number">5</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">6</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">7</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">8</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">9</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">10</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">11</div>
            </div>
            
            <!-- Week 3 (Oct 12-18) -->
            <div class="calendar-day">
                <div class="calendar-day-number">12</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">13</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">14</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">15</div>
            </div>
            <div class="calendar-day today">
                <div class="calendar-day-number">16</div>
                <div class="calendar-event">Today</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">17</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">18</div>
            </div>
            
            <!-- Week 4 (Oct 19-25) -->
            <div class="calendar-day">
                <div class="calendar-day-number">19</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">20</div>
                <div class="calendar-event">Web Dev Workshop</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">21</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">22</div>
                <div class="calendar-event">Career Fair 2025</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">23</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">24</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">25</div>
                <div class="calendar-event">Data Science Seminar</div>
            </div>
            
            <!-- Week 5 (Oct 26 - Nov 1) -->
            <div class="calendar-day">
                <div class="calendar-day-number">26</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">27</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">28</div>
                <div class="calendar-event">Leadership Summit</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">29</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">30</div>
            </div>
            <div class="calendar-day">
                <div class="calendar-day-number">31</div>
            </div>
            <div class="calendar-day" style="opacity: 0.5;">
                <div class="calendar-day-number">1</div>
                <div class="calendar-event">Photo Workshop</div>
            </div>
        </div>
        
        <!-- Event Legend -->
        <div class="mt-lg">
            <h3 class="mb-md">Upcoming Events Details</h3>
            <div class="grid grid-2">
                <div class="card">
                    <h4 class="text-red">Oct 20 - Web Development Workshop</h4>
                    <p><strong>Time:</strong> 2:00 PM - 4:00 PM</p>
                    <p><strong>Location:</strong> Tech Lab 101</p>
                    <p>Learn modern web development techniques.</p>
                </div>
                <div class="card">
                    <h4 class="text-red">Oct 22 - Career Fair 2025</h4>
                    <p><strong>Time:</strong> 10:00 AM - 3:00 PM</p>
                    <p><strong>Location:</strong> Main Auditorium</p>
                    <p>Connect with top employers.</p>
                </div>
                <div class="card">
                    <h4 class="text-red">Oct 25 - Data Science Seminar</h4>
                    <p><strong>Time:</strong> 3:00 PM - 5:00 PM</p>
                    <p><strong>Location:</strong> Science Building 205</p>
                    <p>Explore data science and AI trends.</p>
                </div>
                <div class="card">
                    <h4 class="text-red">Oct 28 - Leadership Summit</h4>
                    <p><strong>Time:</strong> 1:00 PM - 4:00 PM</p>
                    <p><strong>Location:</strong> Student Center</p>
                    <p>Develop leadership skills.</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>