<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $fullname = $_POST['fullname'] ?? '';
    $email = $_POST['email'] ?? '';
    $studentid = $_POST['studentid'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm-password'] ?? '';
    $termsAgreed = isset($_POST['terms']);

    if (!$fullname || !$email || !$studentid || !$password || !$confirmPassword) {
        die("Please fill in all required fields.");
    }
    if ($password !== $confirmPassword) {
        die("Passwords do not match.");
    }
    if (!$termsAgreed) {
        die("You must agree to the Terms and Conditions.");
    }

    $username = strstr($email, '@', true);
    $passwordHash = $password;

    $userData = [
        'username' => $username,
        'email' => $email,
        'password_hash' => $passwordHash,
        'level' => 'User'
    ];

    // Updated URL
    $appUrl = 'http://127.0.0.1:5000/create_user';

    $ch = curl_init($appUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($userData));
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 201) {
        echo "Account created successfully!";
    } else {
        echo "Error creating account: $response";
    }
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Symvan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- ===================================
         SIGN UP PAGE
         Registration page for new users
         =================================== -->
    
    <div class="auth-page">
        <div class="auth-container">
            <!-- Logo/Branding -->
            <div class="auth-logo">
                <h1>Symvan</h1>
                <p class="text-grey">Campus Event Management</p>
            </div>
            
            <!-- Sign Up Form -->
            <div class="form-container">
                <h2 class="text-center mb-md">Create Account</h2>
                
                <form action="signup.php" method="POST">
                    <!-- Full Name Input -->
                    <div class="form-group">
                        <label for="fullname" class="form-label">Full Name</label>
                        <input 
                            type="text" 
                            id="fullname" 
                            name="fullname" 
                            class="form-input" 
                            placeholder="John Doe"
                            required
                        >
                    </div>
                    
                    <!-- Email Input -->
                    <div class="form-group">
                        <label for="email" class="form-label">Email Address</label>
                        <input 
                            type="email" 
                            id="email" 
                            name="email" 
                            class="form-input" 
                            placeholder="your.email@university.edu"
                            required
                        >
                        <p class="form-hint">Use your university email address</p>
                    </div>
                    
                    <!-- Student ID Input -->
                    <div class="form-group">
                        <label for="studentid" class="form-label">Student ID</label>
                        <input 
                            type="text" 
                            id="studentid" 
                            name="studentid" 
                            class="form-input" 
                            placeholder="123456789"
                            required
                        >
                    </div>
                    
                    <!-- Password Input -->
                    <div class="form-group">
                        <label for="password" class="form-label">Password</label>
                        <input 
                            type="password" 
                            id="password" 
                            name="password" 
                            class="form-input" 
                            placeholder="Create a strong password"
                            required
                        >
                    </div>
                    
                    <!-- Confirm Password Input -->
                    <div class="form-group">
                        <label for="confirm-password" class="form-label">Confirm Password</label>
                        <input 
                            type="password" 
                            id="confirm-password" 
                            name="confirm-password" 
                            class="form-input" 
                            placeholder="Re-enter your password"
                            required
                        >
                    </div>
                    
                    <!-- Terms Agreement -->
                    <div class="form-group">
                        <label>
                            <input type="checkbox" class="form-checkbox" name="terms" required>
                            I agree to the <a href="contact.php">Terms and Conditions</a>
                        </label>
                    </div>
                    
                    <!-- Submit Button -->
                    <button type="submit" class="btn btn-primary btn-block">
                        Create Account
                    </button>
                </form>
                
                <!-- Additional Links -->
                <div class="auth-links">
                    <p>Already have an account? <a href="login.php">Sign in here</a></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>