<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enroll in Events - Symvan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- ===================================
         NAVIGATION BAR
         =================================== -->
    <nav class="navbar">
        <div class="navbar-container">
            <a href="index.html" class="navbar-brand">Symvan</a>
            <ul class="navbar-menu">
                <li><a href="index.html">Home</a></li>
                <li><a href="myevents.html">My Events</a></li>
                <li><a href="enroll.html" class="active">Enroll</a></li>
                <li><a href="create-event.html">Create Event</a></li>
                <li><a href="profile.html">Profile</a></li>
                <li><a href="contact.html">Contact</a></li>
            </ul>
        </div>
    </nav>
    
    <!-- ===================================
         ENROLL PAGE
         Browse and enroll in campus events
         =================================== -->
    <div class="container">
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">Browse Events</h1>
            <p class="page-subtitle">Select events you'd like to attend</p>
        </div>
        
        <!-- Event Grid with Checkboxes -->
        <div class="event-grid">
            <!-- Event Card 1 -->
            <div class="card event-card">
                <input type="checkbox" class="event-checkbox" id="event1">
                <div class="card-header">
                    <h3 class="card-title">Web Development Workshop</h3>
                    <div class="card-meta">
                        <span class="card-meta-item">📅 Oct 20, 2025</span>
                        <span class="card-meta-item">🕐 2:00 PM</span>
                    </div>
                </div>
                <div class="card-body">
                    <p><strong>Location:</strong> Tech Lab 101</p>
                    <p>Learn modern web development techniques including HTML5, CSS3, and responsive design principles. Perfect for beginners!</p>
                </div>
                <div class="card-footer">
                    <span>45/50 spots</span>
                    <span class="text-red">5 spots left</span>
                </div>
            </div>
            
            <!-- Event Card 2 -->
            <div class="card event-card">
                <input type="checkbox" class="event-checkbox" id="event2">
                <div class="card-header">
                    <h3 class="card-title">Career Fair 2025</h3>
                    <div class="card-meta">
                        <span class="card-meta-item">📅 Oct 22, 2025</span>
                        <span class="card-meta-item">🕐 10:00 AM</span>
                    </div>
                </div>
                <div class="card-body">
                    <p><strong>Location:</strong> Main Auditorium</p>
                    <p>Connect with top employers and explore career opportunities across various industries. Bring your resume!</p>
                </div>
                <div class="card-footer">
                    <span>120/200 spots</span>
                    <span class="text-red">80 spots left</span>
                </div>
            </div>
            
            <!-- Event Card 3 -->
            <div class="card event-card">
                <input type="checkbox" class="event-checkbox" id="event3">
                <div class="card-header">
                    <h3 class="card-title">Data Science Seminar</h3>
                    <div class="card-meta">
                        <span class="card-meta-item">📅 Oct 25, 2025</span>
                        <span class="card-meta-item">🕐 3:00 PM</span>
                    </div>
                </div>
                <div class="card-body">
                    <p><strong>Location:</strong> Science Building 205</p>
                    <p>Explore the latest trends in data science, machine learning, and AI applications with industry experts.</p>
                </div>
                <div class="card-footer">
                    <span>30/40 spots</span>
                    <span class="text-red">10 spots left</span>
                </div>
            </div>
            
            <!-- Event Card 4 -->
            <div class="card event-card">
                <input type="checkbox" class="event-checkbox" id="event4">
                <div class="card-header">
                    <h3 class="card-title">Campus Leadership Summit</h3>
                    <div class="card-meta">
                        <span class="card-meta-item">📅 Oct 28, 2025</span>
                        <span class="card-meta-item">🕐 1:00 PM</span>
                    </div>
                </div>
                <div class="card-body">
                    <p><strong>Location:</strong> Student Center</p>
                    <p>Develop your leadership skills and network with student leaders across campus organizations.</p>
                </div>
                <div class="card-footer">
                    <span>25/30 spots</span>
                    <span class="text-red">5 spots left</span>
                </div>
            </div>
            
            <!-- Event Card 5 -->
            <div class="card event-card">
                <input type="checkbox" class="event-checkbox" id="event5">
                <div class="card-header">
                    <h3 class="card-title">Photography Workshop</h3>
                    <div class="card-meta">
                        <span class="card-meta-item">📅 Nov 1, 2025</span>
                        <span class="card-meta-item">🕐 4:00 PM</span>
                    </div>
                </div>
                <div class="card-body">
                    <p><strong>Location:</strong> Arts Building Studio</p>
                    <p>Learn professional photography techniques, composition, and lighting. Camera provided if needed.</p>
                </div>
                <div class="card-footer">
                    <span>15/20 spots</span>
                    <span class="text-red">5 spots left</span>
                </div>
            </div>
            
            <!-- Event Card 6 -->
            <div class="card event-card">
                <input type="checkbox" class="event-checkbox" id="event6">
                <div class="card-header">
                    <h3 class="card-title">Entrepreneurship Pitch Night</h3>
                    <div class="card-meta">
                        <span class="card-meta-item">📅 Nov 5, 2025</span>
                        <span class="card-meta-item">🕐 6:00 PM</span>
                    </div>
                </div>
                <div class="card-body">
                    <p><strong>Location:</strong> Innovation Hub</p>
                    <p>Watch student entrepreneurs pitch their startup ideas to a panel of investors and mentors.</p>
                </div>
                <div class="card-footer">
                    <span>50/60 spots</span>
                    <span class="text-red">10 spots left</span>
                </div>
            </div>
        </div>
        
        <!-- Enrollment Confirmation Section -->
        <div class="text-center mt-lg">
            <button class="btn btn-primary btn-block confirm-btn" style="max-width: 400px; margin: 0 auto;">
                Confirm Enrollment
            </button>
            
            <!-- Visual Confirmation Message (shown on button press via CSS) -->
            <div class="confirmation-message">
                ✓ Successfully enrolled! Check your email for confirmation details.
            </div>
        </div>
    </div>
</body>
</html>